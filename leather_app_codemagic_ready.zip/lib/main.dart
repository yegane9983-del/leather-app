
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();

  await Hive.openBox('products');
  await Hive.openBox('history');

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.brown,
        brightness: Brightness.dark,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final productBox = Hive.box('products');
  final historyBox = Hive.box('history');

  final nameController = TextEditingController();
  final usageController = TextEditingController();
  final qtyController = TextEditingController();
  final actualController = TextEditingController();
  final searchController = TextEditingController();

  int selectedIndex = 0;

  List get filtered {
    final q = searchController.text.toLowerCase();
    if (q.isEmpty) return productBox.values.toList();

    return productBox.values
        .where((e) => e["name"].toLowerCase().contains(q))
        .toList();
  }

  void addProduct() {
    if (nameController.text.isEmpty || usageController.text.isEmpty) return;

    productBox.add({
      "name": nameController.text,
      "usage": double.parse(usageController.text),
    });

    setState(() {});
  }

  void deleteProduct(int i) {
    productBox.deleteAt(i);
    setState(() {});
  }

  void calculate() {
    if (productBox.isEmpty) return;

    final p = productBox.getAt(selectedIndex);

    final qty = double.tryParse(qtyController.text) ?? 0;
    final actual = double.tryParse(actualController.text) ?? 0;

    final standard = qty * p["usage"];
    final diff = actual - standard;

    historyBox.add({
      "name": p["name"],
      "standard": standard,
      "actual": actual,
      "diff": diff,
      "date": DateTime.now().toString(),
    });

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Result"),
        content: Text("Diff: $diff"),
      ),
    );

    setState(() {});
  }

  Future<void> exportBackup() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File("${dir.path}/backup.json");

    final data = {
      "products": productBox.values.toList(),
      "history": historyBox.values.toList(),
    };

    await file.writeAsString(jsonEncode(data));

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Backup saved")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Leather App")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [

              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: "Name"),
              ),

              TextField(
                controller: usageController,
                decoration: const InputDecoration(labelText: "Usage"),
              ),

              ElevatedButton(
                onPressed: addProduct,
                child: const Text("Add"),
              ),

              TextField(
                controller: searchController,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(labelText: "Search"),
              ),

              ListView.builder(
                shrinkWrap: true,
                itemCount: filtered.length,
                itemBuilder: (c, i) {
                  final p = filtered[i];
                  return ListTile(
                    title: Text(p["name"]),
                    subtitle: Text("${p["usage"]}"),
                  );
                },
              ),

              const Divider(),

              ElevatedButton(
                onPressed: calculate,
                child: const Text("Calculate"),
              ),

              ElevatedButton(
                onPressed: exportBackup,
                child: const Text("Backup"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
